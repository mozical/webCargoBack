// 信息完善
function closeWindow(){
    model.alertPageHtml = localhostPaht +　"/PublicHtml/empty.html";
}